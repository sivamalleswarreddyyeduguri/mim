package com.zettamine.mi.service;

public interface UserService {
		
	boolean FindByUserIdAndUserPassword(Integer id, String password);
	
}
