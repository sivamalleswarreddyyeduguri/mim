package com.zettamine.mi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterialInspectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
